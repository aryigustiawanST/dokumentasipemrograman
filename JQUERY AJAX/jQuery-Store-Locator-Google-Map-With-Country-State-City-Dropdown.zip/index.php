<!DOCTYPE html>
<html>
  <head>
    <title>jQuery Store Locator Google Map With Country, State, City Dropdown</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="map-assets/css/storelocator.css" />
  </head>

  <body>

 <div class="bh-sl-container">

	<div class="bh-sl-form-container">
	<!-- Forms  -->
		<form id="bh-sl-user-location" method="post" action="#">
			<div class="form-input">
				<label for="bh-sl-address">Enter Area or Zip Code:</label>
				<input type="text" id="bh-sl-address" name="bh-sl-address" />
				<select id="bh-sl-maxdistance" name="bh-sl-maxdistance">
					<option value="5">5 Miles</option>
					<option value="10">10 Miles</option>
					<option value="25">25 Miles</option>
					<option value="50">50 Miles</option>
				</select>
			</div>

			<button id="bh-sl-submit" type="submit">Submit</button>
        </form>
	<!-- Forms  -->
	<!-- Custom Country Filter Dropdown -->
		<div class="bh-sl-filters-container">

			<ul id="country-filter" class="bh-sl-filters">
				<li><h3>Country</h3></li>
				<li>
					<select name="country" id="countyList" size="1">
						<option value="">Please select Country</option>
					</select>
				</li>
			</ul>
			
			<ul id="state-filter" class="bh-sl-filters">
				<li><h3>State</h3></li>
				<li>
					<select name="state" id="stateList" size="1">
						<option value="">Please select State</option>
					</select>
				</li>
			</ul>


			<ul id="city-filter" class="bh-sl-filters">
				<li><h3>City</h3></li>
				<li>
					<select name="city" id="cityList" size="1">
						<option value="">Please select State first</option>
					</select>
				</li>
			</ul>
			
		</div>
	<!-- Custom Country Filter Dropdown -->
		
	</div>

	<!-- List Map Location & Details  -->
	<div id="bh-sl-map-container" class="bh-sl-map-container">
		<div id="bh-sl-map" class="bh-sl-map"></div>
		<div class="bh-sl-loc-list">
			<ul class="list"></ul>
		</div>
	</div>
	<!-- List Map Location & Details  -->
</div>

<script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="map-assets/js/libs/handlebars.min.js"></script>
<script src="https://maps.google.com/maps/api/js?key=YOUR-API-KEY"></script>
<script src="map-assets/js/plugins/storeLocator/storelocator.js"></script>

<script>
	// Auto Geolocation and other Customization.
	 jQuery(function($) {
		$('#bh-sl-map-container').storeLocator({
			autoGeocode: true,
			maxDistance: false,	
			slideMap : true,
			defaultLoc: true,
			defaultLat: '13.0827',
			defaultLng : '80.2707',
			taxonomyFilters : {
				'country' : 'country-filter',
				'state' : 'state-filter',
				'city' : 'city-filter'
			}
		});
	});
</script>


<script>
// JavaScript Locations Array Data
	var worldData = {
		USA: {
			Alaska: ["Fairbanks", "Anchorage"],
			NewYork: ["Brooklyn", "Island"],
			Texas: ["San Antonio", "Austin"],
		},
		India: {
			Maharashtra: ["Mumbai", "Nagpur"],
			TamilNadu: ["Chennai", "Madurai"],
		},
		Canada: {
			Alberta: ["Grande Prairie", "Edmonton"],
			Saskatchewan: ["Saskatoon"],
		},
	};
	window.onload = function () {
		var countyList = document.getElementById("countyList"),
			stateList = document.getElementById("stateList"),
			cityList = document.getElementById("cityList");
		for (var country in worldData) {
			countyList.options[countyList.options.length] = new Option(country, country);
		}
		countyList.onchange = function () {
			stateList.length = 1;
			cityList.length = 1;
			if (this.selectedIndex < 1) return;
			for (var state in worldData[this.value]) {
				stateList.options[stateList.options.length] = new Option(state, state);
			}
		};
		countyList.onchange();
		stateList.onchange = function () {
			cityList.length = 1;
			if (this.selectedIndex < 1) return;
			var city = worldData[countyList.value][this.value];
			for (var i = 0; i < city.length; i++) {
				cityList.options[cityList.options.length] = new Option(city[i], city[i]);
			}
		};
	};
</script>

  </body>
</html>