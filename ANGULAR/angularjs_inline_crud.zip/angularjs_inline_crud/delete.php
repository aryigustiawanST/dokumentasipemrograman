<?php
// MySQL Connection 
include('conn.php');

$message = '';

$form_data = json_decode(file_get_contents("php://input"));

$query = "DELETE FROM user_data WHERE id = '".$form_data->id."'";

$statement = $connect->prepare($query);
if($statement->execute())
{
 $message = 'Record Deleted Successfully';
}

$output = array(
 'message' => $message
);

echo json_encode($output);
?>