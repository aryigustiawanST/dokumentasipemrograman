<?php  
// MySQL Connection 
include('conn.php');

$message = '';

$form_data = json_decode(file_get_contents("php://input"));

$data = array(
 ':username'  => $form_data->username,
 ':user_email'  => $form_data->user_email
);

$query = "
 INSERT INTO user_data 
 (username, user_email) VALUES 
 (:username, :user_email)
";

$statement = $connect->prepare($query);

if($statement->execute($data))
{
 $message = 'Record Inserted Successfully';
}

$output = array(
 'message' => $message
);

echo json_encode($output);
?>