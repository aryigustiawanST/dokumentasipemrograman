<?php  
// MySQL Connection 
include('conn.php');

$message = '';

$form_data = json_decode(file_get_contents("php://input"));

$data = array(
 ':username'  => $form_data->username,
 ':user_email'  => $form_data->user_email,
 ':id'    => $form_data->id
);

$query = "
 UPDATE user_data 
 SET username = :username, user_email = :user_email 
 WHERE id = :id
";

$statement = $connect->prepare($query);
if($statement->execute($data))
{
 $message = 'Record Updated Successfully';
}

$output = array(
 'message' => $message
);

echo json_encode($output);
?>