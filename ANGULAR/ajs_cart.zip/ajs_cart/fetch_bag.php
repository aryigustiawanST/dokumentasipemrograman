<?php
session_start();

if(isset($_SESSION["shopping_bag"]))
{
	echo json_encode($_SESSION["shopping_bag"]);	
}
?>