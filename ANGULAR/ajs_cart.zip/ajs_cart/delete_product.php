<?php
session_start();

$proInfo = json_decode(file_get_contents("php://input"));
$p_id = $proInfo;

foreach($_SESSION["shopping_bag"] as $keys => $values)
{
	if($values["p_id"] == $p_id)
	{
		unset($_SESSION["shopping_bag"][$keys]);
	}
}

?>