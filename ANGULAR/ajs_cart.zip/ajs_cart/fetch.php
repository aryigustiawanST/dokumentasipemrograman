<?php
// DB Connection 
include('conn.php');

$query = "SELECT * FROM sa_product";
$statement = $connect->prepare($query);
$statement->execute();
while($row = $statement->fetch(PDO::FETCH_ASSOC))
{
	$data[] = $row;
}

echo json_encode($data);

?>