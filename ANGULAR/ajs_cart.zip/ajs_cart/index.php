<?php
session_start();
?>
<!DOCTYPE html>
<html>
	<head>
		<title>AngularJS Shopping Cart With PHP MySQL - softAOX</title>
		<link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
 		<style>
		.products {
			border: 1px solid #f1f1f1;
			box-shadow: 1px 2px 10px 1px #f7f7f7;
			text-align: center;
			padding: 10px;
			border-radius: 4px;
		}
		</style>
	</head>
	<body>
	
		<div class="container" ng-app="myBag" ng-controller="bagController" ng-init="fetchPro(); fetchCart();">
			<br />
			<h3 align="center">AngularJS Shopping Cart With PHP MySQL </h3>
			<br />
			<div class="row">
			<div class="col-md-6">
			<h3 align="center">Shop Now</h3>
			<form method="post">
				<div class="row">
					<div class="col-md-6" ng-repeat = "product in products">
						<div class="products">
							<img ng-src="images/{{product.pro_image}}" class="img-fluid" style="width:auto; height:150px;" /><br />
							<h5 class="text-info">{{product.pro_name}}</h5>
							<h6>${{product.pro_price}}</h6>
							<button type="button" name="add_to_cart" class="btn btn-info form-control" ng-click="add_to_bag(product)" > Add to Bag</button>
							
						</div>
					</div>
				</div>
			</form>

			</div>
			<div class="col-md-6">

			<h3 align="center">My Shopping Bag</h3>
			<div class="table-responsive">
				<table class="table table-bordered">
					<tr>  
						<th width="40%">Product Name</th>  
						<th width="10%">Quantity</th>  
						<th width="20%">Price</th>  
						<th width="15%">Total</th>  
						<th width="5%">Action</th>  
					</tr>
					<tr ng-repeat = "cart in carts">
						<td>{{cart.product_name}}</td>
						<td>{{cart.product_qty}}</td>
						<td>${{cart.product_price}}</td>
						<td>${{cart.product_qty * cart.product_price}}</td>
						<td><button type="button" class="btn btn-danger btn-xs" ng-click="delete_pro(cart.p_id)">X</button></td>
					</tr>
					<tr>
						<td colspan="3" align="right">Total</td>
						<td colspan="2">${{ total_Price() }}</td>
					</tr>
				</table>
				<button type="button" class="btn btn-success form-control" > Checkout</button>
			</div>
			</div>

			</div>

		</div>
		<script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
		<script>

		var app = angular.module('myBag', []);

		app.controller('bagController', function($scope, $http){
			
			$scope.fetchPro = function(){
				$http.get('fetch.php').success(function(data){
					$scope.products = data;
				})
			};
			
			$scope.carts = [];
			
			$scope.fetchCart = function(){
				$http.get('fetch_bag.php').success(function(data){
					$scope.carts = data;
				})
			};
			
			$scope.total_Price = function(){
				var total = 0;
				for(var count = 0; count<$scope.carts.length; count++)
				{
					var item = $scope.carts[count];
					total = total + (item.product_qty * item.product_price);
				}
				return total;
			};
			
			$scope.add_to_bag = function(product){
				$http({
					method:"POST",
					url:"add_product.php",
					data:product
				}).success(function(data){
					$scope.fetchCart();
				});
			};
			
			$scope.delete_pro = function(id){
				$http({
					method:"POST",
					url:"delete_product.php",
					data:id
				}).success(function(data){
					$scope.fetchCart();
				});
			};
			
		});

		</script>
	</body>
</html>
