<?php
session_start();
$proInfo = json_decode(file_get_contents("php://input"));
$p_id = $proInfo->id;
$product_name = $proInfo->pro_name;
$product_price = $proInfo->pro_price;

if(isset($_SESSION["shopping_bag"]))
{
	$is_available = 0;
	foreach($_SESSION["shopping_bag"] as $keys => $values)
	{
		if($_SESSION["shopping_bag"][$keys]['p_id'] == $p_id)
		{
			$is_available++;
			$_SESSION["shopping_bag"][$keys]['product_qty'] = $_SESSION["shopping_bag"][$keys]['product_qty'] + 1;
		}
	}
	if($is_available == 0)
	{
		$item_array = array(
			'p_id'               =>     $p_id,  
			'product_name'             =>     $product_name,  
			'product_price'            =>     $product_price,  
			'product_qty'         =>     1
		);
		$_SESSION["shopping_bag"][] = $item_array;
	}
}
else
{
	$item_array = array(
		'p_id'               =>     $p_id,  
		'product_name'             =>     $product_name,  
		'product_price'            =>     $product_price,  
		'product_qty'         =>     1
	);
	$_SESSION["shopping_bag"][] = $item_array;
	
}
?>