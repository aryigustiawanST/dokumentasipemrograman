<?php
 $host = "localhost";  
 $db_user = "root";  
 $db_pass = "";  
 $dbname = "tut";  

 $connect = new PDO("mysql:host=$host; dbname=$dbname", $db_user, $db_pass); 

$form_data = json_decode(file_get_contents("php://input"));

$query = '';
$data = array();

if(isset($form_data->data_search))
{
 $data_search = $form_data->data_search;
 $query = "
 SELECT * FROM user_details 
 WHERE (UserName LIKE '%$data_search%' 
 OR Address LIKE '%$data_search%' 
 OR City LIKE '%$data_search%' 
 OR PostalCode LIKE '%$data_search%' 
 OR Country LIKE '%$data_search%') 
 OR Email = '$data_search'
 ";
}
else
{
 $query = "SELECT * FROM user_details ORDER BY UserName ASC";
}

$statement = $connect->prepare($query);

if($statement->execute())
{
 while($row = $statement->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
 echo json_encode($data);
}

?>