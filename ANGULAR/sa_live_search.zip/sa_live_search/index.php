<!DOCTYPE html>
<html>
 <head>
  <title>AngularJS Live Data Search using PHP MySQL - softAOX</title>
  <link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
 </head>
 <body>
 <style>
 .form-control-borderless {
    border: none;
}

.form-control-borderless:hover, .form-control-borderless:active, .form-control-borderless:focus {
    border: none;
    outline: none;
    box-shadow: none;
}
 </style>
  
  <div class="container" ng-app="myApp" ng-controller="dataController" ng-init="fetchData()">
   <br />
   <h3 align="center">AngularJS Live Data Search using PHP MySQL</h3>
   <br />

   <div class="col-md-12">
        <form class="card card-sm">
            <div class="card-body row no-gutters align-items-center">
                <div class="col-auto">
                    <i class="fas fa-search h4 text-body"></i>
                </div>
                <!--end of col-->
                <div class="col">
                    <input class="form-control form-control-lg form-control-borderless" type="search" name="data_search" ng-model="data_search" ng-keyup="fetchData()" placeholder="Search topics or keywords">
                </div>
                <!--end of col-->
                <div class="col-auto">
                    <button class="btn btn-lg btn-success" type="submit">Search</button>
                </div>
                <!--end of col-->
            </div>
        </form>
    </div>


   <br />
   <table class="table table-striped">
    <thead>
     <tr>
      <th>User Name</th>
      <th>Email</th>
      <th>Address</th>
      <th>City</th>
      <th>Postal Code</th>
      <th>Country</th>
     </tr>
    </thead>
    <tbody>
     <tr ng-repeat="data in searchData">
      <td>{{ data.UserName }}</td>
      <td>{{ data.Email }}</td>
      <td>{{ data.Address }}</td>
      <td>{{ data.City }}</td>
      <td>{{ data.PostalCode }}</td>
      <td>{{ data.Country }}</td>
     </tr>
    </tbody>
   </table>
  </div>
  <script src="js/angular.min.js"></script>
 <script>
var app = angular.module('myApp', []);
app.controller('dataController', function($scope, $http){
 $scope.fetchData = function(){
  $http({
   method:"POST",
   url:"fetch.php",
   data:{data_search:$scope.data_search}
  }).success(function(data){
   $scope.searchData = data;
  });
 };
});
</script>
 </body>
</html>

