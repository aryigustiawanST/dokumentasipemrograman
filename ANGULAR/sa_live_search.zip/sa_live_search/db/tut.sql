-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Jul 17, 2019 at 05:42 AM
-- Server version: 10.1.40-MariaDB
-- PHP Version: 7.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tut`
--

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `UserID` int(11) NOT NULL,
  `UserName` varchar(255) NOT NULL,
  `Email` varchar(255) NOT NULL,
  `Address` text NOT NULL,
  `City` varchar(250) NOT NULL,
  `PostalCode` varchar(30) NOT NULL,
  `Country` varchar(100) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`UserID`, `UserName`, `Email`, `Address`, `City`, `PostalCode`, `Country`) VALUES
(1, 'Maria Anders', 'maria@gmail.com', 'Obere Str. 57', 'Berlin', '12209', 'Germany'),
(2, 'Mohan Raj', 'mraj@softaox.info', 'Avda. de la Construction 2222', 'TamilNadu', '5021', 'India'),
(3, 'Antonio Moreno', 'anto@gmail.com', 'Mataderos 2312', 'Mexico D.F.', '5023', 'Mexico'),
(4, 'Hardy', 'hardy@gmail.com', '120 Hanover Sq.', 'London', 'WA1 1DP', 'United Kingdom'),
(5, 'Paula Parente', 'paula@softaox.info', 'Rua do Mercado, 12', 'Resende', '08737-363', 'Brazil'),
(6, 'Wolski Zbyszek', 'wolski@gmail.com', 'ul. Filtrowa 68', 'Walla', '01-012', 'Poland'),
(7, 'Matti Karttunen', 'matti@yahoo.com', 'Keskuskatu 45', 'Helsinki', '21240', 'Finland'),
(8, 'Karl Jablonski', 'karl@yahoo.com', '305 - 14th Ave. S. Suite 3B', 'Seattle', '98128', 'United States'),
(9, 'Paula Parente', 'paula@gmail.com', 'Rua do Mercado, 12', 'Resende', '08737-363', 'Brazil'),
(10, 'John Koskitalo', 'john@gmail.com', 'Torikatu 38', 'Oulu', '90110', 'Finland'),
(11, 'Ann Devon', 'ann@softaox.info', '35 King George', 'London', 'WX3 6FW', 'United Kingdom'),
(12, 'Janine Labrune', 'janine@softaox.info', '67, rue des Cinquante Otages', 'Nantes', '44000', 'Finland'),
(13, 'Kathryn Segal', 'kathryn@gmail.com', 'Augsburger Strabe 40', 'Ludenscheid Gevelndorf', '58513', 'Germany'),
(14, 'Elizabeth Brown', 'elizabeth@softaox.info', 'Berkeley Gardens 12 Brewery', 'London', 'WX1 6LT', 'United Kingdom'),
(15, 'Trina Davidson', 'trina@gmail.com', '1049 Lockhart Drive', 'Barrie', 'ON L4M 3B1', 'Canada'),
(16, 'Siva', 'siva@softaox.info', 'Industrieweg 56', 'TamilNadu', '7803', 'India'),
(17, 'Joyce Rosenberry', 'joyce@gmail.com', 'Norra Esplanaden 56', 'HELSINKI', '380', 'Finland'),
(18, 'Ronald Bowne', 'ronald@softaox.info', '2343 Shadowmar Drive', 'New Orleans', '70112', 'United States'),
(19, 'Justin Adams', 'justin@gmail.com', '45, rue de Lille', 'ARMENTIERES', '59280', 'France'),
(20, 'Pedro Afonso', 'pedro@gmail.com', 'Av. dos Lusiadas, 23', 'Sao Paulo', '05432-043', 'Brazil');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`UserID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `UserID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
