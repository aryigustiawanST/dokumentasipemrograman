<?php
 $host = "localhost";  
 $db_user = "root";  
 $db_pass = "";  
 $dbname = "tut_angular";  

 $conn = new PDO("mysql:host=$host; dbname=$dbname", $db_user, $db_pass); 
$query = "SELECT * FROM users ORDER BY id ASC";
$pagefetch = $conn->prepare($query);
if($pagefetch->execute())
{
 while($row = $pagefetch->fetch(PDO::FETCH_ASSOC))
 {
  $data[] = $row;
 }
 echo json_encode($data);
}

?>
