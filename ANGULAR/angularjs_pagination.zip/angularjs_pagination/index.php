<!DOCTYPE html>
<html>

<head>
    <title> AngularJS Pagination with PHP MySQL - softAOX</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
</head>

<body>
    <div class="container" ng-app="myPagination" ng-controller="pageController">
        <br/>
        <h1 align="center"> AngularJS Pagination with PHP MySQL</h1>
        <br/>
        <br/>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>S. No</th>
                        <th>User Name</th>
                        <th>Email Address</th>
                    </tr>
                </thead>
                <tbody>
                    <tr dir-paginate="userData in myData|itemsPerPage:5">
                        <td>{{ userData.id }}</td>
                        <td>{{ userData.user_name }}</td>
                        <td>{{ userData.email }}</td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="col-md-12">
            <dir-pagination-controls max-size="5" direction-links="true" boundary-links="true">
            </dir-pagination-controls>
        </div>
    </div>
    <script src="http://ajax.googleapis.com/ajax/libs/angularjs/1.5.7/angular.min.js"></script>
    <script src="dirPaginate.js"></script>
    <script>
        var pagination_app = angular.module('myPagination', ['angularUtils.directives.dirPagination']);
        pagination_app.controller('pageController', function($scope, $http) {
            $http.get('fetch.php').success(function(data) {
                $scope.myData = data;
            });
        });
    </script>
</body>

</html>