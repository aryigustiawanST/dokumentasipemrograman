<?php  
 $connect = mysqli_connect("localhost", "root", "", "angular_tu");  
 $output = '';  
 $query = "SELECT * FROM angularjs_file_upload ORDER BY id DESC";  
 $result = mysqli_query($connect, $query);  
 while($row = mysqli_fetch_array($result))  
 {  
      $output[] = $row;  
 }  
 echo json_encode($output);  
 ?> 